import java.util.Scanner;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;

public class principal {

	public static void main(String[] args) throws JSONException {

		Scanner scan = new Scanner(System.in);
		int opcion;
		int idLlibre;

		// Menu con todas las opciones

		do {
			System.out.println("");
			System.out.println("GESTIO BIBLIOTECA");
			System.out.println("_________________________________________________");
			System.out.println("");
			System.out.println("1. Mostrar tots els títols de la biblioteca");
			System.out.println("2. Mostrar informació detallada d’un llibre");
			System.out.println("3. Crear nou llibre");
			System.out.println("4. Actualitzar llibre");
			System.out.println("5. Borrar llibre");
			System.out.println("6. Tanca la biblioteca");
			System.out.println("_________________________________________________");

			System.out.println("Tria una opcio: (1...6) ");
			opcion = scan.nextInt();

			switch (opcion) {
			case 1:
				mostrarLlibres();
				break;
			case 2:
				System.out.println("Id del llibre: ");
				idLlibre = scan.nextInt();
				mostrarLlibre(idLlibre);
				break;
			case 3:
				crearLlibre();
				break;
			case 4:
				System.out.println("Id del llibre: ");
				idLlibre = scan.nextInt();
				modificarLlibre(idLlibre);

				break;
			case 5:
				System.out.println("Id del llibre a eliminar: ");
				idLlibre = scan.nextInt();
				borrarLlibre(idLlibre);

				break;
			default:
				break;
			}
		} while (opcion != 6);
	}

	// Lee y muestra todos los objetos de la base de datos
	public static void mostrarLlibres() throws JSONException {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("Biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("Llibres");

		MongoCursor<Document> cursor = coleccion.find().iterator();
		while (cursor.hasNext()) {
			JSONObject obj = new JSONObject(cursor.next().toJson());
			System.out.println("Llibre " + obj.getString("Id") + ": " + obj.getString("Titol"));
		}

		mongoClient.close();

	}

	// Compruba las id de todos los objetos hasta encontrar el que coincida y lo
	// muestra
	public static void mostrarLlibre(int id) throws JSONException {

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("Biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("Llibres");

		MongoCursor<Document> cursor = coleccion.find().iterator();
		while (cursor.hasNext()) {
			JSONObject obj = new JSONObject(cursor.next().toJson());
			String identificador = obj.getString("Id");
			if (Integer.parseInt(identificador) == id) {
				System.out.println("Informacio del llibre " + identificador);
				String titol = obj.getString("Titol");
				System.out.println("Titol: " + titol);
				String autor = obj.getString("Autor");
				System.out.println("Autor: " + autor);
				String anyNaixement = obj.getString("Any_naixement");
				System.out.println("Any naixement del autor: " + anyNaixement);
				String anyPublicacio = obj.getString("Any_publicacio");
				System.out.println("Any de publicacio: " + anyPublicacio);
				String editorial = obj.getString("Editorial");
				System.out.println("Editorial: " + editorial);
				String numPagines = obj.getString("Nombre_pagines");
				System.out.println("Numero de pagines: " + numPagines);
			}
		}

		mongoClient.close();

	}

	// Pide variables y crea un objeti Llibre en la base de datos con ellas
	public static void crearLlibre() throws JSONException {
		Scanner scan = new Scanner(System.in);

		System.out.println("Titol: ");
		String titol = scan.nextLine();

		System.out.println("Autor: ");
		String autor = scan.nextLine();

		System.out.println("Any naixement del autor: ");
		String anyNaixement = scan.nextLine();

		System.out.println("Any de publicacio: ");
		String anyPublicacio = scan.nextLine();

		System.out.println("Editorial: ");
		String editorial = scan.nextLine();

		System.out.println("Numero de pagines: ");
		String numPagines = scan.nextLine();

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("Biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("Llibres");

		MongoCursor<Document> cursor = coleccion.find().iterator();
		int lastId = 0;

		while (cursor.hasNext()) {
			JSONObject obj = new JSONObject(cursor.next().toJson());
			lastId = Integer.parseInt(obj.getString("Id"));
		}
		String id = String.valueOf(lastId + 1);

		Document doc = new Document();
		doc.append("Id", id);
		doc.append("Titol", titol);
		doc.append("Autor", autor);
		doc.append("Any_naixement", anyNaixement);
		doc.append("Any_publicacio", anyPublicacio);
		doc.append("Editorial", editorial);
		doc.append("Nombre_pagines", numPagines);

		coleccion.insertOne(doc);

		mongoClient.close();

	}

	// Modifica los datos de un objeto dada su Id
	public static void modificarLlibre(int id) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Titol: ");
		String titol = scan.nextLine();

		System.out.println("Autor: ");
		String autor = scan.nextLine();

		System.out.println("Any naixement del autor: ");
		String anyNaixement = scan.nextLine();

		System.out.println("Any de publicacio: ");
		String anyPublicacio = scan.nextLine();

		System.out.println("Editorial: ");
		String editorial = scan.nextLine();

		System.out.println("Numero de pagines: ");
		String numPagines = scan.nextLine();

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("Biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("Llibres");

		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Titol", titol)));
		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Autor", autor)));
		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Any_naixement", anyNaixement)));
		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Any_publicacio", anyPublicacio)));
		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Editorial", editorial)));
		coleccion.updateOne(eq("Id", id + ""), new Document("$set", new Document("Nombre_pagines", numPagines)));

		mongoClient.close();

	}

	// Borra un objeto Llibre dada su id
	public static void borrarLlibre(int id) {
		Scanner scan = new Scanner(System.in);

		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("Biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("Llibres");

		coleccion.deleteOne(eq("Id", id + ""));

		mongoClient.close();

	}

}