import java.io.Console;
import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

public class Menu {

	public static void main(String[] args)
			throws SAXException, IOException, ParserConfigurationException, TransformerException {

		Biblioteca biblioteca = new Biblioteca();
		Scanner scan = new Scanner(System.in);
		int numOpcion;
		String opcion;

		do {
			System.out.println("");
			System.out.println("GESTIO BIBLIOTECA");
			System.out.println("_________________________________________________");
			System.out.println("");
			System.out.println("1. Mostrar tots els títols de la biblioteca");
			System.out.println("2. Mostrar informació detallada d’un llibre");
			System.out.println("3. Crear nou llibre");
			System.out.println("4. Actualitzar llibre");
			System.out.println("5. Borrar llibre");
			System.out.println("6. Tanca la biblioteca");
			System.out.println("_________________________________________________");

			System.out.println("Tria una opcio: (1...6) ");
			opcion = scan.nextLine();
			numOpcion = Integer.parseInt(opcion);

			switch (numOpcion) {
			case 1:
				biblioteca.mostrarBiblioteca();
				break;
			case 2:
				Libro llibre = new Libro();
				System.out.println("Id del llibre: ");
				String id = scan.nextLine();
				llibre = biblioteca.recuperarLlibre(Integer.parseInt(id));
				biblioteca.mostrarLlibre(llibre);
				break;
			case 3:
				int nouId = biblioteca.crearId();

				System.out.println("Titol del llibre: ");
				String nouTitol = scan.nextLine();

				System.out.println("Autor del llibre: ");
				String nouAutor = scan.nextLine();

				System.out.println("Any publicacio del llibre: ");
				String nouAny = scan.nextLine();

				System.out.println("Editorial del llibre: ");
				String nouEditorial = scan.nextLine();

				System.out.println("Pagines del llibre: ");
				String nouPagines = scan.nextLine();

				Libro noullibre = new Libro(nouId, nouTitol, nouAutor, Integer.parseInt(nouAny), nouPagines,
						Integer.parseInt(nouPagines));

				biblioteca.crearLlibre(noullibre);

				System.out.println("Nou llibre creat: ");
				biblioteca.mostrarLlibre(noullibre);

				break;
			case 4:
				System.out.println("Id del llibre a actulitzar: ");
				id = scan.nextLine();

				biblioteca.actualitzaLlibre(Integer.parseInt(id));

				System.out.println("Llibre actulitzat");

				break;
			case 5:
				System.out.println("Id del llibre a eliminar: ");
				id = scan.nextLine();
				biblioteca.borrarLlibre(Integer.parseInt(id));
				System.out.println("LLibre eliminat");

				break;
			case 6:

				break;
			default:
				break;
			}
		} while (numOpcion != 6);

	}

}
