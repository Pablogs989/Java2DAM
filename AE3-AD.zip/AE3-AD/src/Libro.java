

public class Libro {

	private int identificador; 
	private String titol; 
	private String autor;
	private int any;
	private String editorial;
    private int paginas;
    
    public Libro() {    }

    public Libro(int identificador, String titol, String autor, int any, String editorial, int paginas) {
        this.identificador = identificador;
        this.titol = titol;
        this.autor = autor;
        this.any = any;
        this.editorial = editorial;
        this.paginas = paginas;
    }
	
    public int getIdentificador() {
		return identificador;
	}
    public String getTitol() {
		return titol;
	}
    public String getAutor() {
		return autor;
	}
    public int getAny() {
		return any;
	}
    public String getEditorial() {
		return editorial;
	}
    public int getPaginas() {
		return paginas;
	}
    
}
