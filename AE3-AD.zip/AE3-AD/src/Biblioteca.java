
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Biblioteca {

	private List<Libro> llibres = new ArrayList<Libro>();

	public List<Libro> getLlibres() {
		return llibres;
	}

	public Biblioteca() {
		try {
			this.llibres = this.recuperarTots();
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
	}

	public void anyadirLlibre(Libro llibre) {
		llibres.add(llibre);

	}

	public void mostrarBiblioteca() throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(new File("biblioteca.xml"));

		Element raiz = document.getDocumentElement();
		System.out.println("Contenido XML " + raiz.getNodeName() + ":");
		NodeList nodeList = document.getElementsByTagName("Llibre");

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			System.out.println("");
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) node;
				System.out.println("Id: " + eElement.getAttribute("id"));
				System.out.println("Titol: " + eElement.getElementsByTagName("titulo").item(0).getTextContent());
				System.out.println("Autor: " + eElement.getElementsByTagName("autor").item(0).getTextContent());
				System.out.println("Any publicacio: "
						+ eElement.getElementsByTagName("anyo_publicacion").item(0).getTextContent());
				System.out.println("Editorial: " + eElement.getElementsByTagName("editorial").item(0).getTextContent());
				System.out.println("Pagines: " + eElement.getElementsByTagName("paginas").item(0).getTextContent());
			}
		}
	}

	public void mostrarLlibre(Libro llibre) {
		System.out.println("Id: " + llibre.getIdentificador());
		System.out.println("Titol: " + llibre.getTitol());
		System.out.println("Autor: " + llibre.getAutor());
		System.out.println("Any publicacio: " + llibre.getAny());
		System.out.println("Editorial: " + llibre.getEditorial());
		System.out.println("Pagines: " + llibre.getPaginas());
	}

	public List<Libro> recuperarTots() throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(new File("biblioteca.xml"));

		NodeList nodeList = document.getElementsByTagName("Llibre");

		List<Libro> llibres = new ArrayList<Libro>();

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			System.out.println("");
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) node;
				Libro llibre = new Libro(Integer.parseInt(eElement.getAttribute("id")),
						eElement.getElementsByTagName("titulo").item(0).getTextContent(),
						eElement.getElementsByTagName("autor").item(0).getTextContent(),
						Integer.parseInt(eElement.getElementsByTagName("anyo_publicacion").item(0).getTextContent()),
						eElement.getElementsByTagName("editorial").item(0).getTextContent(),
						Integer.parseInt(eElement.getElementsByTagName("paginas").item(0).getTextContent()));
				llibres.add(llibre);
			}
		}
		return llibres;
	}

	public Libro recuperarLlibre(int id) throws ParserConfigurationException, SAXException, IOException {
		List<Libro> llibres = this.recuperarTots();

		for (Libro libro : llibres) {
			if (libro.getIdentificador() == id) {
				return libro;
			}
		}
		return null;
	}

	public int crearLlibre(Libro llibre) throws TransformerException, IOException, ParserConfigurationException {
		DocumentBuilderFactory dFact = DocumentBuilderFactory.newInstance();
		DocumentBuilder build = dFact.newDocumentBuilder();
		Document doc = build.newDocument();
		Element raiz = doc.createElement("Biblioteca");
		doc.appendChild(raiz);
		for (Libro l : llibres) {
			Element llib = doc.createElement("Llibre");
			String id = String.valueOf(l.getIdentificador());
			llib.setAttribute("id", id);
			raiz.appendChild(llib);
			Element titulo = doc.createElement("titulo");
			titulo.appendChild(doc.createTextNode(String.valueOf(l.getTitol())));
			llib.appendChild(titulo);
			Element autor = doc.createElement("autor");
			autor.appendChild(doc.createTextNode(String.valueOf(l.getAutor())));
			llib.appendChild(autor);
			Element anyo_publicacion = doc.createElement("anyo_publicacion");
			anyo_publicacion.appendChild(doc.createTextNode(String.valueOf(l.getAny())));
			llib.appendChild(anyo_publicacion);
			Element editorial = doc.createElement("editorial");
			editorial.appendChild(doc.createTextNode(String.valueOf(l.getEditorial())));
			llib.appendChild(editorial);
			Element paginas = doc.createElement("paginas");
			paginas.appendChild(doc.createTextNode(String.valueOf(l.getPaginas())));
			llib.appendChild(paginas);
		}
		Element llib = doc.createElement("Llibre");
		String id = String.valueOf(llibre.getIdentificador());
		llib.setAttribute("id", id);
		raiz.appendChild(llib);
		Element titulo = doc.createElement("titulo");
		titulo.appendChild(doc.createTextNode(String.valueOf(llibre.getTitol())));
		llib.appendChild(titulo);
		Element autor = doc.createElement("autor");
		autor.appendChild(doc.createTextNode(String.valueOf(llibre.getAutor())));
		llib.appendChild(autor);
		Element anyo_publicacion = doc.createElement("anyo_publicacion");
		anyo_publicacion.appendChild(doc.createTextNode(String.valueOf(llibre.getAny())));
		llib.appendChild(anyo_publicacion);
		Element editorial = doc.createElement("editorial");
		editorial.appendChild(doc.createTextNode(String.valueOf(llibre.getEditorial())));
		llib.appendChild(editorial);
		Element paginas = doc.createElement("paginas");
		paginas.appendChild(doc.createTextNode(String.valueOf(llibre.getPaginas())));
		llib.appendChild(paginas);

		TransformerFactory tranFactory = TransformerFactory.newInstance();
		Transformer aTransformer = tranFactory.newTransformer();
		aTransformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
		aTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource source = new DOMSource(doc);
		FileWriter fw = new FileWriter("biblioteca.xml");

		StreamResult result = new StreamResult(fw);
		aTransformer.transform(source, result);
		fw.close();
		return llibre.getIdentificador();
	}

	public int crearId() {
		int max = 0;
		for (Libro libro : llibres) {
			if (libro.getIdentificador() > max) {
				max = libro.getIdentificador();
			}
		}
		return max + 1;
	}

	void borrarLlibre(int identificador) throws ParserConfigurationException, TransformerFactoryConfigurationError,
			SAXException, IOException, TransformerException {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File("biblioteca.xml"));

		NodeList items = doc.getElementsByTagName("Llibre");
		for (int ix = 0; ix < items.getLength(); ix++) {
			Element element = (Element) items.item(ix);
			if (element.getAttribute("id").equalsIgnoreCase(String.valueOf(identificador))) {
				element.getParentNode().removeChild(element);
			}
		}
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		Result output = new StreamResult(new File("biblioteca.xml"));
		Source input = new DOMSource(doc);
		transformer.transform(input, output);
	}

	void actualitzaLlibre(int identificador) throws ParserConfigurationException, TransformerFactoryConfigurationError,
			SAXException, IOException, TransformerException {
		Scanner scan = new Scanner(System.in);
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File("biblioteca.xml"));

		NodeList items = doc.getElementsByTagName("Llibre");
		Libro noullibre = new Libro();
		for (int ix = 0; ix < items.getLength(); ix++) {
			Element element = (Element) items.item(ix);
			if (element.getAttribute("id").equalsIgnoreCase(String.valueOf(identificador))) {
				int nouId = identificador;

				System.out.println("Titol del llibre: ");
				String nouTitol = scan.nextLine();

				System.out.println("Autor del llibre: ");
				String nouAutor = scan.nextLine();

				System.out.println("Any publicacio del llibre: ");
				String nouAny = scan.nextLine();

				System.out.println("Editorial del llibre: ");
				String nouEditorial = scan.nextLine();

				System.out.println("Pagines del llibre: ");
				String nouPagines = scan.nextLine();

				noullibre = new Libro(identificador, nouTitol, nouAutor, Integer.parseInt(nouAny), nouEditorial,
						Integer.parseInt(nouPagines));
				element.getParentNode().removeChild(element);
			}
		}
		this.crearLlibre(noullibre);
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		Result output = new StreamResult(new File("biblioteca.xml"));
		Source input = new DOMSource(doc);
		transformer.transform(input, output);
	}

}
